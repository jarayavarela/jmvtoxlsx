# Inicio

<p style="text-align: justify;">
Este software ha sido desarrollado como apoyo para la realización del Trabajo de Fin de Máster del <strong>Máster en Transporte, Territorio y Urbanismo de la Universidad Politécnica de Valencia</strong>.
</p>


## Resumen

<p style="text-align: justify;">
<strong>jsontoxlsx</strong> es una herramienta especializada en la conversión y análisis de datos de movilidad provenientes de <strong>Google Location History</strong> en formato JSON. Este software transforma automáticamente estos datos en archivos Excel (.xlsx), permitiendo compararlos con diarios de viaje tradicionales para evaluar la eficiencia en la integración de ambos tipos de datos.
</p>
