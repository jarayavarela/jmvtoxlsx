# Versiones


## Versión 1.0.2 - Mejora en la Visualización del Excel de Salida

En esta versión, se han realizado ajustes en la visualización del archivo Excel generado. Se han corregido los anchos de columnas para mejorar la legibilidad y presentación de los datos.


## Versión 1.0.1 - Actualización de Dependencias

En esta versión, se han incorporado dependencias adicionales para mejorar la funcionalidad de la biblioteca exportable.


## Versión 1.0.0 - Versión de Pruebas Iniciales

Esta es la primera versión del software, diseñada para realizar pruebas y validar la biblioteca exportable en distintos dispositivos.



